[app]
title = Alien Shooter
package.name = alienshooter
package.domain = org.ishant
source.dir = .
source.include_exts = py,png,wav,txt
version = 0.1
requirements = hostpython3==3.10.12,python3==3.10.12,pygame
orientation = portrait
fullscreen = 1
android.archs = arm64-v8a
android.api = 33
android.minapi = 21
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
