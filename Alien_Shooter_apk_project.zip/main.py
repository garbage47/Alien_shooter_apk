import pygame
import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))

def _scale_by(surf, k):
	w, h = surf.get_size()
	return pygame.transform.scale(surf, (int(w*k), int(h*k)))
if not hasattr(pygame.transform, 'scale_by'):
	pygame.transform.scale_by = _scale_by
from sys import exit
from random import randint
pygame.init()

screen = pygame.display.set_mode((600,1000), pygame.SCALED)

#bg music-
bg_music = pygame.mixer.Sound("Assets/Audio/Bg_music.wav")
bg_music.play(loops = -1)

explode_sound_effect = pygame.mixer.Sound("Assets/Audio/Explode.wav")
explode_sound_effect.set_volume(.7)

kill_sound_effect_sound_effect = pygame.mixer.Sound("Assets/Audio/fail.wav")

hurt_sound_effect = pygame.mixer.Sound("Assets/Audio/Hurt.wav")

#Auto high score reading :
if (not os.path.exists("best_score.txt")):
	with open("best_score.txt","w") as new:
		best_score_variable = 0
		new.write(f"High_Score:{best_score_variable}")

else:
	with open("best_score.txt","r") as best_score_file:
		unfiltered_best_score = best_score_file.read()
		best_score_variable = int(unfiltered_best_score.split(":")[1])

#clock-
clock = pygame.time.Clock()
#bg
galaxy = pygame.image.load("Assets/Graphics/Galaxy.png").convert()
galaxy = pygame.transform.scale(galaxy,(600,1000))
bg  = pygame.image.load("Assets/Graphics/Space.png").convert()
bg = pygame.transform.scale(bg,(600,1000))

#font related-
fps_font = pygame.font.Font(None,30)
font = pygame.font.Font(None,40)
game_name_font = pygame.font.Font(None,80)

score = 0
previous_score = 0

def draw_fps(fps_font):
	fps = clock.get_fps()
	fps_surface = fps_font.render(f"FPS : {fps:.0f}",False,(34,34,34))
	fps_rect = fps_surface.get_rect(topleft = (10,10))
	
	screen.blit(fps_surface,fps_rect)

def in_game_score(font):
	global score,previous_score
	score = (pygame.time.get_ticks() - previous_score )/1000
	font_surface = font.render(f"Score : {int(score)}",False,(25,25,25))
	
	font_rect = font_surface.get_rect(center = (300,400))
	
	screen.blit(font_surface,font_rect)

def game_name_display(game_name_font):
	font_surface = game_name_font.render("ALIEN SHOOTER ",False,(87,87,87))
	font_rect = font_surface.get_rect(topleft = (50,50))
	
	pygame.draw.rect(screen,(185,145,0),font_rect)
	pygame.draw.rect(screen,(0,0,0),font_rect,2)
	screen.blit(font_surface,font_rect)

def instructions(font):
	font_surface_1 = font.render("Start Game",False,(27,27,27))
	font_surface_2 = font.render("Dodge Bullets and Break High Score!",False,(90,90,90))
	
	font_rect_1 = font_surface_1.get_rect(topleft = (50,500))
	font_rect_2 = font_surface_2.get_rect(topleft = (50,550))

	screen.blit(font_surface_1,font_rect_1)
	screen.blit(font_surface_2,font_rect_2)

def kill_sound_effect_score(font):
	global score 
	font_surface = font.render(f"Score : {int(score)}",False,(124,24,124))
	font_rect = font_surface.get_rect(topleft = (50,525))
	
	screen.blit(font_surface,font_rect)

def stand():
	stand_image = pygame.image.load("Assets/Graphics/Alien_1.png").convert_alpha()
	stand_image = pygame.transform.scale_by(stand_image,10)
	
	stand_rect = stand_image.get_rect(center = (300,300))
	
	screen.blit(stand_image,stand_rect)


#writting best score function-
def best_score_display(font):
	global best_score_variable,score
	if score > best_score_variable:
		best_score_variable = score
		with open("best_score.txt","w") as best_score_file:
			best_score_file.write(f"High_Score:{int(best_score_variable)}")
			
	font_surface = font.render(f"Highest Score : {int(best_score_variable)}",False,"Black")
	
	font_rect = font_surface.get_rect(topleft = (50,580))
	
	screen.blit(font_surface,font_rect)
#additional variable-
touch_pos = None
game_active = False
kill_sound_effect = False
#classes-
class Player(pygame.sprite.Sprite):
	def __init__(self):
		super().__init__()
		self.heart = 3
		image_1 = pygame.image.load("Assets/Graphics/Aircraft_1.png").convert_alpha()
		image_2 = pygame.image.load("Assets/Graphics/Aircraft_2.png").convert_alpha()
		
		image_1 = pygame.transform.scale_by(image_1,5)
		image_2 = pygame.transform.scale_by(image_2,5)
		
		self.frames = [image_1,image_2]
		self.index = 0
		
		self.image = self.frames[self.index]
		
		self.rect = self.image.get_rect(midtop = (300,650))
	
	def move_left(self):
		self.rect.x -= 5
		if self.rect.x < 0 :
			self.rect.x = 0
	
	def move_right(self):
		self.rect.x += 5
		if self.rect.x > 525:
			self.rect.x = 525
	
	def Animate(self):
		if self.index == 0:
			self.index = 1
		else:
			self.index = 0
		
		self.image = self.frames[self.index]
		
		
player = pygame.sprite.GroupSingle()
player.add(Player())

class Alien(pygame.sprite.Sprite):
	def __init__(self):
		super().__init__()
		self.heart = 3
		image_1 = pygame.image.load("Assets/Graphics/Alien_1.png").convert_alpha()
		image_2 = pygame.image.load("Assets/Graphics/Alien_2.png").convert_alpha()
		
		image_1 = pygame.transform.scale_by(image_1,3.5)
		image_2 = pygame.transform.scale_by(image_2,3.5)
		self.frames = [image_1,image_2]
		self.index = 0
		self.image = image_1 
		
		self.rect = self.image.get_rect(midbottom = (randint(100,500),randint(-70,-50)))

	def movement(self):
		if score > 50:
			self.rect.y += 1.3
		elif score > 20:
			self.rect.y += 1.2
		elif score > 10:
			self.rect.y += 1.1
		else:
			self.rect.y += 1
		if self.rect.y > 800:
			self.kill()
			
	def death_check(self):
		if self.heart <= 0:
			explode_sound_effect.play()
			self.kill()
			
	def update(self):
		self.movement()
		self.death_check()
		
	def Animate(self):
		if self.index == 0:
			self.index = 1
		else:
			self.index = 0
		
		self.image = self.frames[self.index]
		
alien = pygame.sprite.Group()

#bullet image-
image_1 = pygame.image.load("Assets/Graphics/Bullet.png").convert_alpha()
image_1 = pygame.transform.scale_by(image_1,2)

class Bullet(pygame.sprite.Sprite):
	def __init__(self,type):
		super().__init__()
		image_2 = pygame.transform.rotate(image_1,180)
		self.image = image_1
		
		if type == "Left":
			self.x = player.sprite.rect.x + 10
		else:
			self.x = player.sprite.rect.x + 90

		self.rect = self.image.get_rect(midtop = (self.x ,620))
			
	def movement(self):
		self.rect.y -= 2

		if self.rect.y < -10:
			self.kill()
	def update(self):
		self.movement()

class Enemy_bullet(pygame.sprite.Sprite):
	def __init__(self):
		super().__init__()
		self.image = pygame.transform.rotate(image_1,180)
		

		self.x = sprite.rect.x + 30
		self.y = sprite.rect.y + 80
		
		self.rect = self.image.get_rect(midbottom = (self.x,self.y))

	def movement(self):
		self.rect.y += 2.1
		
		if self.rect.y > 800:
			self.kill()
	
	def update(self):
		self.movement()

bullet = pygame.sprite.Group()
enemy_bullet = pygame.sprite.Group()

bullet_timer = pygame.USEREVENT +1 
pygame.time.set_timer(bullet_timer,1250)

enemy_bullet_timer = pygame.USEREVENT + 2
pygame.time.set_timer(enemy_bullet_timer,5000)

#timer-
alien_spawn_timer = pygame.USEREVENT + 3
pygame.time.set_timer(alien_spawn_timer,5000)

animation_timer = pygame.USEREVENT + 4
pygame.time.set_timer(animation_timer,350)

#buttons -
Left_Button = pygame.image.load("Assets/Graphics/Left_Button.png").convert()
Left_Button = pygame.transform.scale_by(Left_Button,8)
Right_Button = pygame.transform.rotate(Left_Button,180)

Left_Button_rect = Left_Button.get_rect(topleft = (100,860))
Right_Button_rect = Right_Button.get_rect(topleft = (380,860))


#Hearts-
heart = pygame.image.load("Assets/Graphics/Heart.png").convert_alpha()

heart = pygame.transform.scale_by(heart,7)
heart_rect_1 = heart.get_rect(topleft = (10,730))
heart_rect_2 = heart.get_rect(topleft = (60,730))
heart_rect_3 = heart.get_rect(topleft = (110,730))

#collisions related functions-
def bullet_collide():
	global game_active
	for sprites in alien:
		if pygame.sprite.spritecollide(sprites,bullet,False):
			for unit in bullet:
				if pygame.sprite.spritecollide(unit,alien,False):
					sprites.heart -= 1
					unit.kill()
		if pygame.sprite.spritecollide(player.sprite,alien,False):
			player.sprite.heart -= 1
			hurt_sound_effect.play()
			for sprite in alien:
				if pygame.sprite.spritecollide(sprite,player,False):
					sprite.kill()
			if player.sprite.heart <= 0:
				
				game_active = False
				player.sprite.heart = 3
				alien.empty()
				bullet.empty()
				enemy_bullet.empty()
				player.sprite.rect.x = 250

def enemy_bullet_collision():
	global game_active
	if pygame.sprite.spritecollide(player.sprite,enemy_bullet,True):
		player.sprite.heart -= 1
		hurt_sound_effect.play()
	for sprite in bullet:
		if pygame.sprite.spritecollide(sprite,enemy_bullet,True):
			sprite.kill()
while True:
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			pygame.quit()
			exit()	
		if event.type == bullet_timer and game_active:
			bullet.add(Bullet("Left"))
			bullet.add(Bullet("Right"))
		if event.type == enemy_bullet_timer and game_active:
			for sprite in alien:
				enemy_bullet.add(Enemy_bullet())
	
		if event.type == animation_timer and game_active :
			for sprite in alien:
				sprite.Animate()
			player.sprite.Animate()
		if event.type == alien_spawn_timer and game_active:
			alien.add(Alien())
		if event.type == pygame.MOUSEBUTTONDOWN:
			if game_active:
				touch_pos = event.pos
			else:
				game_active = True
		if event.type == pygame.MOUSEBUTTONUP and game_active:
			touch_pos = None
		
	if game_active:
		kill_sound_effect = True
		screen.blit(bg,(0,0))
		in_game_score(font)
		player.draw(screen)
		bullet.draw(screen)
		bullet.update()
		enemy_bullet.draw(screen)
		enemy_bullet.update()
		alien.draw(screen)
		alien.update()
		bullet_collide()
		enemy_bullet_collision()
		
		if player.sprite.heart == 1:
			screen.blit(heart,heart_rect_1)
		elif player.sprite.heart == 2:
			screen.blit(heart,heart_rect_1)
			screen.blit(heart,heart_rect_2)
		elif player.sprite.heart == 3:
			screen.blit(heart,heart_rect_1)
			screen.blit(heart,heart_rect_2)
			screen.blit(heart,heart_rect_3)
			
		for sprite in alien:
			if sprite.rect.bottom > 800:
				player.sprite.heart -= 1
				hurt_sound_effect.play()
				sprite.kill()
		
		if player.sprite.heart <= 0:
			game_active = False
			alien.empty()
			bullet.empty()
			enemy_bullet.empty()
			player.sprite.heart = 3
			
		pygame.draw.rect(screen,(15,15,30),(0,800,600,200))
		screen.blit(Left_Button,Left_Button_rect)
		screen.blit(Right_Button,Right_Button_rect)
		
		if touch_pos:
			if Left_Button_rect.collidepoint(touch_pos):
				player.sprite.move_left()
			elif Right_Button_rect.collidepoint(touch_pos):
				player.sprite.move_right()

	else:
		if kill_sound_effect :
			kill_sound_effect_sound_effect.play()
			kill_sound_effect = False
		previous_score = pygame.time.get_ticks()
		screen.blit(galaxy,(0,0))
		kill_sound_effect_score(font)
		game_name_display(game_name_font)
		instructions(font)
		stand()
		best_score_display(font)
		
	draw_fps(fps_font)	
	pygame.display.update()
	clock.tick(60)